# AI Customer Support (Sample)

This is a minimal, runnable template for an AI-powered customer support web app (Flask).

## Quick start (Windows)
1. Create virtual env:
   ```powershell
   python -m venv venv
   .\venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and fill keys.
3. Run:
   ```powershell
   python app.py
   ```
4. Open http://localhost:5000

## Contents
- `app.py`: minimal Flask app with a mock "AI" reply.
- `requirements.txt`: Python dependencies.
- `templates/`: HTML template.
- `static/`: CSS.
- `docker/`: Dockerfile example.
