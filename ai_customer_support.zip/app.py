from flask import Flask, render_template, request, jsonify
from dotenv import load_dotenv
import os

load_dotenv()
app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/respond', methods=['POST'])
def respond():
    # Dummy "AI" responder - replace with real model calls
    data = request.json or {}
    message = data.get('message', '')
    reply = f"Echo (mock AI): Received your message of {len(message)} chars."
    return jsonify({'reply': reply})

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
